/*Desenvolvido por Roberto Carati*/
let result_geral = 0;
let historico_result_geral = [];
let str_result_geral = "";
let data_prescricao = "";

listar_arts = document.createElement("form");
listar_arts.setAttribute("id", "listar_arts");

function de_dias(dias) {
    let resultado = [];
    let anos1 = dias/360;
    let anos = Math.floor(anos1);
    resultado[0] = anos;
    let meses1 = dias%360;
    let meses2 = meses1/30;
    let meses = Math.floor(meses2);
    resultado[1] = meses;
    let dias1 = meses1%30;
    resultado[2] = dias1;
    return(resultado);
}

function para_dias (ano, mes, dia) {
    let resultado = (ano * 360) + (mes * 30) + (dia * 1);
    return(resultado);
}

function verificar_pena_maxima () {
    let pb_a1 = parseInt(document.getElementById("p_b_a").value);
    let pb_m1 = parseInt(document.getElementById("p_b_m").value);
    let pb_d1 = parseInt(document.getElementById("p_b_d").value);
    let pm_a1 = parseInt(document.getElementById("p_b_a_max").value);
    let pm_m1 = parseInt(document.getElementById("p_b_m_max").value);
    let pm_d1 = parseInt(document.getElementById("p_b_d_max").value);
    let pb = para_dias(pb_a1, pb_m1, pb_d1);
    let pm = para_dias(pm_a1, pm_m1, pm_d1);
    if (pb >= pm) {
        alert("Para a utilização deste atalho é necessário ajustar a Pena Mínima e a Pena Máxima.");
        return(true);
    }
}

function seta_data_inicial() {
    let data = new Date();
    let dia = data.getDate();
    let mes = data.getMonth();
    let ano = data.getFullYear();
    let pr_dia = document.getElementById("pr_d");
    let pr_mes = document.getElementById("pr_m");
    let pr_ano = document.getElementById("pr_a");
    pr_dia.value = dia;
    pr_mes.value = mes + 1;
    pr_ano.value = ano;
}

seta_data_inicial();

function corrige_data_prescricao(presc_d, presc_m, presc_a){
    let meses_com_31 = [0, 1, 3, 5, 7, 8, 10, 12];
    presc_d = parseInt(presc_d);
    presc_m = parseInt(presc_m);
    presc_a = parseInt(presc_a);

    if (presc_d == 0) {
        if (presc_m == 3){
            presc_d = 28;
            presc_m = presc_m - 1;
        } else if (meses_com_31.includes((presc_m - 1))){
            presc_d = 31;
            presc_m = presc_m - 1;
        } else {
            presc_d = 30;
            presc_m = presc_m - 1;
        }

        if (presc_m == 0){
           presc_a = presc_a - 1;
           presc_m = 12;
        }
    }
    return[presc_d, presc_m, presc_a];
}

function prescricao() {
    let presc_d = document.getElementById("pr_d").value;
    let presc_m = document.getElementById("pr_m").value;
    let presc_a = document.getElementById("pr_a").value;
    let prescr_d = 0;
    let prescr_m = 0;
    let prescr_a = 0;

    let prazo = 3;
    if (result_geral > 4320) {
        prazo = 20;
    } else if (result_geral > 2880) {
        prazo = 16;
    } else if (result_geral > 1440) {
        prazo = 12;
    } else if (result_geral > 720) {
        prazo = 8;
    } else if (result_geral >= 360) {
        prazo = 4;
    } else {
        prazo = 3;
    }

    let menor21 = document.getElementById("menor21").checked;
    let maior70 = document.getElementById("maior70").checked;
    if (menor21 === true || maior70 === true) {
        prazo = prazo / 2;
    }

    let prazo2 = "Prazo de: " + prazo + " anos";

    presc_d= presc_d - 1;

    if (prazo == 1.5){
        prazo2 = "Prazo de: 1 ano e 6 meses";
        presc_a = parseInt(presc_a) + 1;
        presc_m = parseInt(presc_m) + 6;
        if (presc_m > 12){
            presc_a = presc_a + 1;
            presc_m = presc_m - 12;
        }
        let prescr = corrige_data_prescricao(presc_d, presc_m, presc_a);
        prescr_d = prescr[0];
        prescr_m = prescr[1];
        prescr_a = prescr[2];
        let dt2 = prescr_d + "/" + prescr_m + "/" + prescr_a;
        let dt3 = "Prescrição em: " + dt2;
        document.getElementById("presc_resultado").innerHTML = dt3;
    } else {
        let prescr = corrige_data_prescricao(presc_d, presc_m, presc_a);
        prescr_d = prescr[0];
        prescr_m = prescr[1];
        prescr_a = prescr[2];
        let presc_anos = parseInt(prescr_a) + prazo;
        let dt2 = prescr_d + "/" + prescr_m + "/" + presc_anos;
        let dt3 = "Prescrição em: " + dt2;
        document.getElementById("presc_resultado").innerHTML = dt3;
    }

    document.getElementById("presc_prazo").innerHTML = prazo2;
}

document.getElementById("result_destaque").addEventListener("change", prescricao);
document.getElementById("pr_d").addEventListener("change", prescricao);
document.getElementById("pr_m").addEventListener("change", prescricao);
document.getElementById("pr_a").addEventListener("change", prescricao);
document.getElementById("prescricao_idade").addEventListener("change", prescricao);

function seta_dados(ord) {
    let x_a = document.getElementById("p_b_a");
    let x_m = document.getElementById("p_b_m");
    let x_d = document.getElementById("p_b_d");
    let xm_a = document.getElementById("p_b_a_max");
    let xm_m = document.getElementById("p_b_m_max");
    let xm_d = document.getElementById("p_b_d_max");
    let mmin = document.getElementById("dm_min");
    let mmax = document.getElementById("dm_max");
    z = penas_comuns[ord].pmin;
    zm = penas_comuns[ord].pmax;
    y = de_dias(z);
    ym = de_dias(zm);
    x_a.value = y[0];
    x_m.value = y[1];
    x_d.value = y[2];
    xm_a.value = ym[0];
    xm_m.value = ym[1];
    xm_d.value = ym[2];
    mmin.value = penas_comuns[ord].multa_min;
    mmax.value = penas_comuns[ord].multa_max;
    let lista = document.getElementById("notas_parent");
    let lista_child = document.getElementById("notas_parent").childElementCount;
    if (lista_child > 0) {
        while (lista.hasChildNodes()) {
            lista.removeChild(lista.firstChild);
        }
    }
    if (penas_comuns[ord].nota) {
        for (let i = 0; i < penas_comuns[ord].nota.length; i++) {
            let item = document.createElement("li");
            item.textContent = (penas_comuns[ord].nota[i]);
            lista.appendChild(item);
        }
    }
    prescricao();
}

for (let i = 0; i < penas_comuns.length; i++) {
    let y = penas_comuns[i].art;
    let x = document.createElement("input");
    x.setAttribute("type", "radio");
    x.setAttribute("name", "pen_com");
    x.setAttribute("id", i);
    x.setAttribute("value", y);
    x.setAttribute("onclick", "seta_dados("+i+")");
    listar_arts.appendChild(x);
    listar_arts.append(y + " - ");
    let x1 = document.createElement("a");
    x1.append("(ver)");
    x1.setAttribute("href", penas_comuns[i].link);
    x1.setAttribute("target", "_blank");
    listar_arts.appendChild(x1);
    let z = document.createElement("br");
    listar_arts.appendChild(z);
}

onde = document.getElementById("tipos_penais").appendChild(listar_arts);

const copyToClipboard = str => {
  const el = document.createElement('textarea');
  el.value = str;
  el.setAttribute('readonly', '');
  el.style.position = 'absolute';
  el.style.left = '-9999px';
  document.body.appendChild(el);
  el.select();
  document.execCommand('copy');
  document.body.removeChild(el);
};

function monta_pena(dias) {
    let tot_str = de_dias(dias);
    let ans = " ano";
    let ms = " mês";
    let ds = " dia ";
    if (tot_str[0] > 1) {
        ans = " anos"
    }
    if (tot_str[1] > 1) {
        ms = " meses";
    }
    if (tot_str[2] > 1) {
        ds = " dias ";
    }
    if (tot_str[0] !== 0 && tot_str[1] !== 0 && tot_str[2] !== 0){        
        return(tot_str[0] + ans + ", " + tot_str[1] + ms + " e " + tot_str[2] + ds);
    } else if (tot_str[0] === 0 && tot_str[1] !== 0 && tot_str[2] !== 0) {
        return(tot_str[1] + ms + " e " + tot_str[2] + ds);
    } else if (tot_str[0] !== 0 && tot_str[1] === 0 && tot_str[2] !== 0) {
        return(tot_str[0] + ans + " e " + tot_str[2] + ds);
    } else if (tot_str[0] !== 0 && tot_str[1] !== 0 && tot_str[2] === 0) {
        return(tot_str[0] + ans + " e " + tot_str[1] + ms);
    } else if (tot_str[0] === 0 && tot_str[1] === 0 && tot_str[2] !== 0) {
        return(tot_str[2] + ds);
    } else if (tot_str[0] === 0 && tot_str[1] !== 0 && tot_str[2] === 0) {
        return(tot_str[1] + ms);
    } else if (tot_str[0] !== 0 && tot_str[1] === 0 && tot_str[2] === 0) {
        return(tot_str[0] + ans);
    } else if (tot_str[0] !== 0 && tot_str[1] === 0 && tot_str[2] !== 0) {
        return(tot_str[0] + ans + " e " + tot_str[2] + ds);
    } else {
        return(0);
    }
    prescricao();
}

function rolar() {
    let elmnt = document.getElementById("res_pb");
    elmnt.scrollIntoView(false);
}

function multa() {
    let min = parseInt(document.getElementById("dm_min").value);
    let max = parseInt(document.getElementById("dm_max").value);
    let pb_a1 = parseInt(document.getElementById("p_b_a").value);
    let pb_m1 = parseInt(document.getElementById("p_b_m").value);
    let pb_d1 = parseInt(document.getElementById("p_b_d").value);
    let pm_a1 = parseInt(document.getElementById("p_b_a_max").value);
    let pm_m1 = parseInt(document.getElementById("p_b_m_max").value);
    let pm_d1 = parseInt(document.getElementById("p_b_d_max").value);
    let pb = para_dias(pb_a1, pb_m1, pb_d1);
    let pm = para_dias(pm_a1, pm_m1, pm_d1);
    let dif_m = max - min;
    let dif_p = pm - pb;
    let fator = dif_m / dif_p;
    let mlt = Math.floor(fator * (result_geral - pb)) + min;
    if (isNaN(mlt)){
        mlt = 0;
    } 
    if (mlt <= min) {
        mlt = min;
    } 
    if (mlt > max) {
        mlt = max;
    } 
    if (mlt === 1) {
        mlt = mlt + " dia-multa";
    } else {
        mlt = mlt + " dias-multa";  
    }
    document.getElementById("resultado_multa").innerHTML = mlt;
}

function copiar_multa() {
    let multa = document.getElementById("resultado_multa").textContent;
    copyToClipboard(multa);
}

function copiar_prescricao() {
    copyToClipboard(data_prescricao);
}


function resultados(sinal, res) {
    let pena = monta_pena(res); 
    copyToClipboard(pena);
    let ds = " dia"
    if (res > 1) {
        ds = " dias"
    }
    let pena1 = sinal + pena + " (" + res + ds + ")";
    document.getElementById("result_destaque").innerHTML = pena;
    let y = document.getElementById("res_pb");
    y.append(pena1);
    let y1 = document.getElementById("titulo1").textContent = "Pena " + pena;
    let z1 = document.createElement("br");
    y.appendChild(z1);
    multa();
    prescricao();
    rolar();
}

function pena_base() {
    let pb_a1 = parseInt(document.getElementById("p_b_a").value);
    let pb_m1 = parseInt(document.getElementById("p_b_m").value);
    let pb_d1 = parseInt(document.getElementById("p_b_d").value);
    let pb_tot = para_dias(pb_a1, pb_m1, pb_d1); 
    result_geral = pb_tot;
    multa();
    resultados("", result_geral);
}

function teste() {
    alert("teste");
}

function novo_calculo() {
    window.open("./Penas.html", "_blank");
}

document.getElementById("tipos_penais").addEventListener("change", pena_base);

function pega_dados_calcular() {
    let c_a = parseInt(document.getElementById("calc_a").value);
    let c_m = parseInt(document.getElementById("calc_m").value);
    let c_d = parseInt(document.getElementById("calc_d").value);
    let pena_d = para_dias(c_a, c_m, c_d);
    return(pena_d);
}

function zero_min() {
    if (result_geral < 0) {
        result_geral = 0;
    }
}

function desfazer() {
    let tamanho = historico_result_geral.length;
    if (tamanho > 0) {
        let ultimo = historico_result_geral[tamanho - 1];
        console.log(tamanho);
        resultados("(D) ", result_geral);
        result_geral = ultimo;
        if (tamanho > 1){
            historico_result_geral.pop();    
        }
        resultados("= ", ultimo);   
    }
    prescricao();
}

function somar(sinal, pena) {
    historico_result_geral.push(result_geral);
    let pena_calc = result_geral + pena;
    result_geral = pena_calc;
    zero_min();
    resultados(sinal, pena);
    resultados("= ", result_geral);
}

function subtrair (sinal, pena) {
    historico_result_geral.push(result_geral);
    let pena_calc = result_geral - pena;
    result_geral = pena_calc;
    zero_min();
    resultados(sinal, pena);
    resultados("= ", result_geral);
}

function calcular_soma() {
    let pena = pega_dados_calcular();
    somar(" (+) ", pena);
}

function calcular_subtr() {
    let pena = pega_dados_calcular();
    subtrair(" (-) ", pena);
}

function atalho_soma(sinal, numerador, denominador) {
    pena = Math.floor(result_geral * numerador / denominador);
    pena_calc = somar(sinal, pena); 
}

function atalho_subtr(sinal, numerador, denominador) {
    pena = Math.ceil(result_geral * numerador / denominador);
    pena_calc = subtrair(sinal, pena); 
}

function cj_desf() {
    let checagem = verificar_pena_maxima();
    if (checagem !== true) {
        let pb_a1 = parseInt(document.getElementById("p_b_a").value);
        let pb_m1 = parseInt(document.getElementById("p_b_m").value);
        let pb_d1 = parseInt(document.getElementById("p_b_d").value);
        let pm_a1 = parseInt(document.getElementById("p_b_a_max").value);
        let pm_m1 = parseInt(document.getElementById("p_b_m_max").value);
        let pm_d1 = parseInt(document.getElementById("p_b_d_max").value);
        let pb = para_dias(pb_a1, pb_m1, pb_d1);
        let pm = para_dias(pm_a1, pm_m1, pm_d1);
        let termo_medio_1 = (pb + pm) / 2;
        let dif_p = termo_medio_1 - pb;
        let diferenca = Math.floor((dif_p / 8) /10) * 10;
        somar(" (+CD) ", diferenca);
    }
}

function soma_1_6() {
    atalho_soma(" (+1/6) ", 1, 6);
}

function subtr_1_6() {
    atalho_subtr(" (-1/6) ", 1, 6);
}
function soma_1_5() {
    atalho_soma(" (+1/5) ", 1, 5);
}

function subtr_1_5() {
    atalho_subtr(" (-1/5) ", 1, 5);
}
function soma_1_4() {
    atalho_soma(" (+1/4) ", 1, 4);
}

function subtr_1_4() {
    atalho_subtr(" (-1/4) ", 1, 4);
}
function soma_1_3() {
    atalho_soma(" (+1/3) ", 1, 3);
}

function subtr_1_3() {
    atalho_subtr(" (-1/3) ", 1, 3);
}
function soma_1_2() {
    atalho_soma(" (+1/2) ", 1, 2);
}

function subtr_1_2() {
    atalho_subtr(" (-1/2) ", 1, 2);
}
function soma_2_5() {
    atalho_soma(" (+2/5) ", 2, 5);
}
function subtr_2_5() {
    atalho_subtr(" (-2/5) ", 2, 5);
}
function soma_2_3() {
    atalho_soma(" (+2/3) ", 2, 3);
}

function subtr_2_3() {
    atalho_subtr(" (-2/3) ", 2, 3);
}

function agravante() {
    atalho_soma(" (+AG) ", 1, 6);
}

function atenuante() {
    historico_result_geral.push(result_geral);
    let pb_a1 = parseInt(document.getElementById("p_b_a").value);
    let pb_m1 = parseInt(document.getElementById("p_b_m").value);
    let pb_d1 = parseInt(document.getElementById("p_b_d").value);
    let pb_tot = para_dias(pb_a1, pb_m1, pb_d1);
    pena = Math.ceil(result_geral * 1 / 6);
    let pena_calc = result_geral - pena;
    if (pena_calc < pb_tot){
        result_geral = pb_tot;
        zero_min();
        resultados(" (PMin) ", pb_tot);
        resultados("= ", result_geral);
    } else {
        atalho_subtr(" (-AT) ", 1, 6);
    }
}


