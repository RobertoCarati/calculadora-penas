/*Desenvolvido por Roberto Carati.
Cadastrar penas em dias,
multiplicar ano por 360,
multiplicar meses por 30.*/

const penas_comuns = [{
    "art" : "334-A (Contrabando)",
    "pmax" : 1800,
    "pmin" : 720,
    "multa_min": 0,
    "multa_max": 0,
    "link": "http://www.planalto.gov.br/ccivil_03/Decreto-Lei/Del2848.htm#art334a",
    "nota": ["Não tem multa penal.", "§ 3º A pena aplica-se em dobro se o crime de contrabando é praticado em transporte aéreo, marítimo ou fluvial."]
},
{
    "art" : "334 (Descaminho)",
    "pmax" : 1440,
    "pmin" : 360,
    "multa_min": 0,
    "multa_max": 0,
    "link": "http://www.planalto.gov.br/ccivil_03/Decreto-Lei/Del2848.htm#art334",
    "nota": ["Não tem multa penal."]
},
{
    "art" : "33 (Tráfico)",
    "pmax" : 5400,
    "pmin" : 1800,
    "multa_min": 500,
    "multa_max": 1500,
    "link": "http://www.planalto.gov.br/ccivil_03/_ato2004-2006/2006/lei/l11343.htm#art33",
    "nota": ["Art. 40. As penas previstas nos arts. 33 a 37 desta Lei são aumentadas de um sexto a dois terços, se: I - a natureza, a procedência da substância ou do produto apreendido e as circunstâncias do fato evidenciarem a transnacionalidade do delito;", "§ 4º Nos delitos definidos no caput e no § 1º deste artigo, as penas poderão ser reduzidas de um sexto a dois terços, (vedada a conversão em penas restritivas de direitos suspensa por decisão definitiva do Supremo Tribunal Federal nos autos do Habeas Corpus nº 97.256/RS), desde que o agente seja primário, de bons antecedentes, não se dedique às atividades criminosas nem integre organização criminosa."]
},
{
    "art" : "35 (Associação)",
    "pmax" : 3600,
    "pmin" : 1080,
    "multa_min": 700,
    "multa_max": 1200,
    "link": "http://www.planalto.gov.br/ccivil_03/_ato2004-2006/2006/lei/l11343.htm#art35",
    "nota": ["Duas ou mais pessoas"]
},
{
    "art" : "36 (Financiamento)",
    "pmax" : 7200,
    "pmin" : 2880,
    "multa_min": 1500,
    "multa_max": 4000,
    "link": "http://www.planalto.gov.br/ccivil_03/_ato2004-2006/2006/lei/l11343.htm#art36",
    "nota": ["Autofinanciamento caracteriza somente art. 33 (STJ)"]
},
{
    "art" : "289 (Moeda Falsa)",
    "pmax" : 4320,
    "pmin" : 1080,
    "multa_min": 10,
    "multa_max": 360,
    "link": "http://www.planalto.gov.br/ccivil_03/Decreto-Lei/Del2848.htm#art289",
    "nota": ["Verificar recebimento de boa-fé."]
},
{
    "art" : "168-A (OmissãoPrev)",
    "pmax" : 1800,
    "pmin" : 720,
    "multa_min": 10,
    "multa_max": 360,
    "link": "http://www.planalto.gov.br/ccivil_03/Decreto-Lei/Del2848.htm#art168a",
    "nota": ["Aumento pela continuidade delitiva, por quantidade de competências (meses), conforme tabela utilizada pelo TRF4:", "0-9: 1/6", "9-18: 1/5 a 1/4", "18-24: 1/4 a 1/3", "24-30: 1/3 a 1/2", "30-33: 1/2 a 2/3", "33-36: 2/3", "Verificar parcelamento, pagamento ou dificuldades financeiras."]
},
{
    "art" : "337-A (SonegaçãoPrev)",
    "pmax" : 1800,
    "pmin" : 720,
    "multa_min": 10,
    "multa_max": 360,
    "link": "http://www.planalto.gov.br/ccivil_03/Decreto-Lei/Del2848.htm#art337a",
    "nota": ["Aumento pela continuidade delitiva, por quantidade de competências (meses), conforme tabela utilizada pelo TRF4:", "0-9: 1/6", "9-18: 1/5 a 1/4", "18-24: 1/4 a 1/3", "24-30: 1/3 a 1/2", "30-33: 1/2 a 2/3", "33-36: 2/3", "Verificar parcelamento, pagamento ou dificuldades financeiras."]
},
{
    "art" : "171, § 3º (Estelionato)",
    "pmax" : 1800,
    "pmin" : 360,
    "multa_min": 10,
    "multa_max": 360,
    "link": "http://www.planalto.gov.br/ccivil_03/Decreto-Lei/Del2848.htm#art171",
    "nota": ["§ 3º A pena aumenta-se de um terço, se o crime é cometido em detrimento de entidade de direito público ou de instituto de economia popular, assistência social ou beneficência."]
},
{
    "art" : "288 (Associação)",
    "pmax" : 1080,
    "pmin" : 360,
    "multa_min": 10,
    "multa_max": 360,
    "link": "http://www.planalto.gov.br/ccivil_03/Decreto-Lei/Del2848.htm#art288",
    "nota": ["Verificar parcelamento, pagamento ou dificuldades financeiras."]
},
{
    "art" : "1º da 8.137/90",
    "pmax" : 1800,
    "pmin" : 720,
    "multa_min": 10,
    "multa_max": 360,
    "link": "http://www.planalto.gov.br/ccivil_03/leis/l8137.htm#art1",
    "nota": ["Súmula Vinculante 24: Não se tipifica crime material contra a ordem tributária, previsto no art. 1º, incisos I a IV, da Lei 8.137/1990, antes do lançamento definitivo do tributo.", "Aumento pela continuidade delitiva, por quantidade de competências (meses), conforme tabela utilizada pelo TRF4:", "0-9: 1/6", "9-18: 1/5 a 1/4", "18-24: 1/4 a 1/3", "24-30: 1/3 a 1/2", "30-33: 1/2 a 2/3", "33-36: 2/3", "Verificar parcelamento, pagamento ou dificuldades financeiras."]
},
{
    "art" : "2º da 8.137/90",
    "pmax" : 720,
    "pmin" : 180,
    "multa_min": 10,
    "multa_max": 360,
    "link": "http://www.planalto.gov.br/ccivil_03/leis/l8137.htm#art2",
    "nota": ["Aumento pela continuidade delitiva, por quantidade de competências (meses), conforme tabela utilizada pelo TRF4:", "0-9: 1/6", "9-18: 1/5 a 1/4", "18-24: 1/4 a 1/3", "24-30: 1/3 a 1/2", "30-33: 1/2 a 2/3", "33-36: 2/3"]
},
{
    "art" : "312 (Peculato)",
    "pmax" : 4320,
    "pmin" : 720,
    "multa_min": 10,
    "multa_max": 360,
    "link": "http://www.planalto.gov.br/ccivil_03/Decreto-Lei/Del2848.htm#art312",
    "nota": ["§ 1º - Aplica-se a mesma pena, se o funcionário público, embora não tendo a posse do dinheiro, valor ou bem, o subtrai, ou concorre para que seja subtraído, em proveito próprio ou alheio, valendo-se de facilidade que lhe proporciona a qualidade de funcionário."]
},
{
    "art" : "297/304 (MatDocPub)",
    "pmax" : 2160,
    "pmin" : 720,
    "multa_min": 10,
    "multa_max": 360,
    "link": "http://www.planalto.gov.br/ccivil_03/Decreto-Lei/Del2848.htm#art297",
    "nota": ["Art. 297 - Falsificar, no todo ou em parte, documento público, ou alterar documento público verdadeiro:", "Pena - reclusão, de dois a seis anos, e multa.", "§ 1º - Se o agente é funcionário público, e comete o crime prevalecendo-se do cargo, aumenta-se a pena de sexta parte.", "Art. 304 - Fazer uso de qualquer dos papéis falsificados ou alterados, a que se referem os arts. 297 a 302: Pena - a cominada à falsificação ou à alteração."]
},
{
    "art" : "299/304 (IdeolDocPub)",
    "pmax" : 1800,
    "pmin" : 360,
    "multa_min": 10,
    "multa_max": 360,
    "link": "http://www.planalto.gov.br/ccivil_03/Decreto-Lei/Del2848.htm#art299",
    "nota": ["Art. 299 - Omitir, em documento público ou particular, declaração que dele devia constar, ou nele inserir ou fazer inserir declaração falsa ou diversa da que devia ser escrita, com o fim de prejudicar direito, criar obrigação ou alterar a verdade sobre fato juridicamente relevante:", "Pena - reclusão, de um a cinco anos, e multa, se o documento é público, e reclusão de um a três anos, e multa, de quinhentos mil réis a cinco contos de réis, se o documento é particular.", "Parágrafo único - Se o agente é funcionário público, e comete o crime prevalecendo-se do cargo, ou se a falsificação ou alteração é de assentamento de registro civil, aumenta-se a pena de sexta parte.", "Art. 304 - Fazer uso de qualquer dos papéis falsificados ou alterados, a que se referem os arts. 297 a 302: Pena - a cominada à falsificação ou à alteração."]
},
{
    "art" : "331 (Desacato)",
    "pmax" : 720,
    "pmin" : 180,
    "multa_min": 0,
    "multa_max": 0,
    "link": "http://www.planalto.gov.br/ccivil_03/Decreto-Lei/Del2848.htm#art331",
    "nota": ["Pena - detenção, de seis meses a dois anos, ou multa."]
},
{
    "art" : "55 da 9.605/98",
    "pmax" : 360,
    "pmin" : 180,
    "multa_min": 10,
    "multa_max": 360,
    "link": "http://www.planalto.gov.br/ccivil_03/leis/l9605.htm#art55",
    "nota": ["Art. 55. Executar pesquisa, lavra ou extração de recursos minerais sem a competente autorização, permissão, concessão ou licença, ou em desacordo com a obtida:", "Parágrafo único. Nas mesmas penas incorre quem deixa de recuperar a área pesquisada ou explorada, nos termos da autorização, permissão, licença, concessão ou determinação do órgão competente."]
},
{
    "art" : "157 (Roubo)",
    "pmax" : 3600,
    "pmin" : 1440,
    "multa_min": 10,
    "multa_max": 360,
    "link": "http://www.planalto.gov.br/ccivil_03/Decreto-Lei/Del2848.htm#art157",
    "nota": ["Verificar, há qualificadoras e diversas causas de aumento de pena."]
},
{
    "art" : "121 (Homicídio)",
    "pmax" : 7200,
    "pmin" : 2160,
    "multa_min": 0,
    "multa_max": 0,
    "link": "http://www.planalto.gov.br/ccivil_03/Decreto-Lei/Del2848.htm#art121",
    "nota": ["Verificar, há qualificadoras e diversas causas de aumento de pena.", "Não tem multa penal."]
},
{
    "art" : "333 (CorrAtiva)",
    "pmax" : 4320,
    "pmin" : 720,
    "multa_min": 10,
    "multa_max": 360,
    "link": "http://www.planalto.gov.br/ccivil_03/Decreto-Lei/Del2848.htm#art333",
    "nota": ["Parágrafo único - A pena é aumentada de um terço, se, em razão da vantagem ou promessa, o funcionário retarda ou omite ato de ofício, ou o pratica infringindo dever funcional."]
},
{
    "art" : "337-F(Licitação)",
    "pmax" : 2880,
    "pmin" : 1440,
    "multa_min": 10,
    "multa_max": 360,
    "link": "http://www.planalto.gov.br/ccivil_03/Decreto-Lei/Del2848.htm#art337f",
    "nota": ["Art. 337-F. Frustrar ou fraudar, com o intuito de obter para si ou para outrem vantagem decorrente da adjudicação do objeto da licitação, o caráter competitivo do processo licitatório:       (Incluído pela Lei nº 14.133, de 2021)"]
},
{
    "art" : "16 da 10.826/03",
    "pmax" : 2160,
    "pmin" : 1080,
    "multa_min": 10,
    "multa_max": 360,
    "link": "http://www.planalto.gov.br/ccivil_03/leis/2003/l10.826.htm#art16",
    "nota": ["Posse ou porte ilegal de arma de fogo de uso restrito"]
}
];
